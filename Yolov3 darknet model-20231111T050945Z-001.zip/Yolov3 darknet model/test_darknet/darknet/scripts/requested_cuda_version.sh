#!/usr/bin/env bash

export CUDA_VERSION="11.6"
export CUDA_VERSION_DASHED="${CUDA_VERSION//./-}"
